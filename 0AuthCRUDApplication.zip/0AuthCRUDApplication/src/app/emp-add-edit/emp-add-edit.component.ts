import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CoreService } from '../core/core.service';


@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.scss']
})
export class EmpAddEditComponent implements OnInit {
  empForm:FormGroup;
  education:string[]=[
    'Metric',
    'Diploma',
    'Intermediate',
    'Graduate',
    'Post-Graduate'
  ]
 
  constructor(
    private fb:FormBuilder, 
    private empService:EmployeeService,
    private dialogRef:MatDialogRef<EmpAddEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any,
    private coreService:CoreService
    ){
    this.empForm=  this.fb.group ({
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      dob:['',Validators.required],
      gender:['',Validators.required],
      education:['',Validators.required],
      company:['',Validators.required],
      experience:['',Validators.required],
      package:['',Validators.required],
    })
  }
  ngOnInit(): void {
  this.empForm.patchValue(this.data)
  }
  
  onFormSubmit(){
    if(this.empForm.valid){
      if(this.data){
        // console.log(this.empForm.value);
        this.empService.updateEmployee( this.data.id,this.empForm.value).subscribe({
          next:(val:any)=>{
            // alert("employee Details Upadted! ")
            this.coreService.openSnackBar('Employee Details Updated!');
            this.dialogRef.close(true);
          },
          error:(err:any)=>{
            console.log(err);
            
          },
        })
       
      }
      else{
        // console.log(this.empForm.value);
        this.empService.addEmployee(this.empForm.value).subscribe({
          next:(val:any)=>{
            // alert("employee added successfully")
            this.coreService.openSnackBar('Employee added successfully');
            this.dialogRef.close(true);
          },
          error:(err:any)=>{
            console.log(err);
            
          },
        })

      }
     
    }
  }

  // firstLetterUpperCase(val:string,txt:any){
  //   // console.log(val);
  //   let firstLetter=val.charAt(0);
  //   let upperCasefirstLetter=firstLetter.toUpperCase();
  //   let rem=val.slice(1);
  //   let caps=upperCasefirstLetter + rem;
  //   console.log(txt)
  //   if(txt == 'firstName'){
  //     this.empForm.get('firstName')?.setValue(caps);
  //   }else{
  //     this.empForm.get('lastName')?.setValue(caps);
  //   }
  //   // this.empForm.get('company')?.setValue(caps);
  //   // console.log('first letter',firstLetter);
  //   // console.log('uppercase',upperCasefirstLetter);
  //   // console.log('remaining',rem);
  //   console.log(caps);
    
  
  //  }

 
    
}
